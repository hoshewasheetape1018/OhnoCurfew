﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace GameTest_v1
{
    internal class BgSky1
{
        Texture2D bgSkyTexture;
        Rectangle bgSkyRectangle;
        Color bgSkyColor;

        public BgSky1(Texture2D bgSkyTexture, Rectangle bgSkyRectangle, Color bgSkyColor)
        {
            this.bgSkyTexture = bgSkyTexture;
            this.bgSkyRectangle = bgSkyRectangle;
            this.bgSkyColor = bgSkyColor;
        }

        public Texture2D BgSkyTexture { get => bgSkyTexture;}
        public Rectangle BgSkyRectangle { get => bgSkyRectangle; }
        public Color BgSkyColor { get => bgSkyColor;}
    }
}
