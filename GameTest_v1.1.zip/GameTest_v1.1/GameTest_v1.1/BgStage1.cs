﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace GameTest_v1
{
    internal class BgStage1
    {
        Texture2D bgStage1Texture;
        Rectangle bgStage1Rectangle;
        Color bgStage1Color;

        public BgStage1(Texture2D bgStage1Texture, Rectangle bgStage1Rectangle, Color bgStage1Color)
        {
            this.bgStage1Texture = bgStage1Texture;
            this.bgStage1Rectangle = bgStage1Rectangle;
            this.bgStage1Color = bgStage1Color;
        }

        public Texture2D BgStage1Texture { get => bgStage1Texture; }
        public Rectangle BgStage1Rectangle { get => bgStage1Rectangle; }
        public Color BgStage1Color { get => bgStage1Color; }
    }
}
