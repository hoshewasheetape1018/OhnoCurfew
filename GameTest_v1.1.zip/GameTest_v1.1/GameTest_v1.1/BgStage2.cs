﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace GameTest_v1
{
    internal class BgStage2
    {
        Texture2D bgStage2Texture;
        Rectangle bgStage2Rectangle;
        Color bgStage2Color;

        public BgStage2(Texture2D bgStage2Texture, Rectangle bgStage2Rectangle, Color bgStage2Color)
        {
            this.bgStage2Texture = bgStage2Texture;
            this.bgStage2Rectangle = bgStage2Rectangle;
            this.bgStage2Color = bgStage2Color;
        }

        public Texture2D BgStage2Texture { get => bgStage2Texture; }
        public Rectangle BgStage2Rectangle { get => bgStage2Rectangle; }
        public Color BgStage2Color { get => bgStage2Color; }
    }
}
