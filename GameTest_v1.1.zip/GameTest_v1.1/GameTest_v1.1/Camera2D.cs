﻿using Microsoft.Xna.Framework;

namespace GameTest_v1
{
    public class Camera2D
    {
        public Matrix Transform { get; private set; }
        public Vector2 Position { get; private set; }

        private int viewportWidth;
        private int viewportHeight;

        public Camera2D(int viewportWidth, int viewportHeight)
        {
            this.viewportWidth = viewportWidth;
            this.viewportHeight = viewportHeight;
        }

        public void Follow(Vector2 target)
        {
            Position = new Vector2(
                target.X - viewportWidth / 2,
                target.Y - viewportHeight / 2
            );

            // Clamp to 0 so camera doesn't go into negative space
            if (Position.X < 0) Position = new Vector2(0, Position.Y);
            if (Position.Y < 0) Position = new Vector2(Position.X, 0);

            Transform = Matrix.CreateTranslation(new Vector3(-Position, 0));
        }

    }
}
