﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using GameTest_v1;

namespace GameTest_v1
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        int currentStage = 1;

        BgSky1 sky;
        BgStage1 stage1;
        BgStage2 stage2;
        Stage2Tiles stage2Tiles;

        Texture2D playerTexture;
        Player player;
        Camera2D camera;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            _graphics.PreferredBackBufferHeight = 1080;
            _graphics.PreferredBackBufferWidth = 1920;
            IsMouseVisible = true;
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            camera = new Camera2D(1920, 1080);

            #region Sky
            Texture2D bgSkyTexture = Content.Load<Texture2D>("Sky");
            Rectangle bgSkyRectangle = new Rectangle(0, 0, 3840, 1080);
            sky = new BgSky1(bgSkyTexture, bgSkyRectangle, Color.White);
            #endregion

            #region Stage 1
            Texture2D bgStage1Texture = Content.Load<Texture2D>("Stage 1");
            Rectangle bgStage1Rectangle = new Rectangle(0, 500, 3682, 692);
            stage1 = new BgStage1(bgStage1Texture, bgStage1Rectangle, Color.White);
            #endregion

            #region Stage 2
            Texture2D bgStage2Texture = Content.Load<Texture2D>("Stage 2 (1)");
            Rectangle bgStage2Rectangle = new Rectangle(0, 0, 3842, 2160);
            stage2 = new BgStage2(bgStage2Texture, bgStage2Rectangle, Color.White);

            Texture2D s2TilesTexture = Content.Load<Texture2D>("Stage 2 Tiles (1)");
            Rectangle s2TilesSource = new Rectangle(0, 0, 3842, 2160);
            Rectangle s2TilesDisplay = new Rectangle(0, 0, 3842, 2160);
            stage2Tiles = new Stage2Tiles(s2TilesTexture, s2TilesDisplay, s2TilesSource, Color.White);
            #endregion

            #region Player
            playerTexture = Content.Load<Texture2D>("MC Idle");
            player = new Player(playerTexture, new Vector2(0, 690));
            #endregion
        }

        protected override void Update(GameTime gameTime)
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            player.Update(gameTime, ref currentStage);
            camera.Follow(player.Position);

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            _spriteBatch.Begin(transformMatrix: camera.Transform);

            _spriteBatch.Draw(sky.BgSkyTexture, sky.BgSkyRectangle, sky.BgSkyColor);

            if (currentStage == 1)
            {
                _spriteBatch.Draw(stage1.BgStage1Texture, stage1.BgStage1Rectangle, stage1.BgStage1Color);
            }
            else if (currentStage == 2)
            {
                _spriteBatch.Draw(stage2.BgStage2Texture, stage2.BgStage2Rectangle, stage2.BgStage2Color);
                _spriteBatch.Draw(stage2Tiles.S2TilesTexture, stage2Tiles.S2TilesDisplay, stage2Tiles.S2TilesSource, stage2Tiles.S2TilesColor);
            }

            player.Draw(_spriteBatch);

            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
