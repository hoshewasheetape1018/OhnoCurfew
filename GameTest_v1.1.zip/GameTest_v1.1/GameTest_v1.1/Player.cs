﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace GameTest_v1
{
    internal class Player
    {
        Texture2D texture;
        Rectangle sourceRect;
        Rectangle positionRect;
        int speed = 5;

        public Player(Texture2D texture, Vector2 position)
        {
            this.texture = texture;
            sourceRect = new Rectangle(0, 0, 128, 128); // 1st frame only
            positionRect = new Rectangle((int)position.X, (int)position.Y, 128, 128); // Scaled sprite
        }

        public void Update(GameTime gameTime, ref int currentStage)
        {
            KeyboardState kState = Keyboard.GetState();

            if (kState.IsKeyDown(Keys.Right))
                positionRect.X += speed;
            if (kState.IsKeyDown(Keys.Left))
                positionRect.X -= speed;

            // Transition to stage 2
            if (currentStage == 1 && positionRect.X >= 1920)
            {
                currentStage = 2;
                positionRect.X = 0;
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, positionRect, sourceRect, Color.White);
        }

        public Vector2 Position => new Vector2(positionRect.X, positionRect.Y);

    }
}
