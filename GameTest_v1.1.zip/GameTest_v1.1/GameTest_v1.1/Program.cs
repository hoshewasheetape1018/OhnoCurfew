﻿using var game = new GameTest_v1.Game1();
game.Run();
