﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace GameTest_v1
{
    internal class Stage2Tiles
    {
        Texture2D s2TilesTexture;
        Rectangle s2TilesDisplay, s2TilesSource;
        Color s2TilesColor;

        public Stage2Tiles(Texture2D s2TilesTexture, Rectangle s2TilesDisplay, Rectangle s2TilesSource, Color s2TilesColor)
        {
            this.s2TilesTexture = s2TilesTexture;
            this.s2TilesDisplay = s2TilesDisplay;
            this.s2TilesSource = s2TilesSource;
            this.s2TilesColor = s2TilesColor;
        }

        public Texture2D S2TilesTexture { get => s2TilesTexture;}
        public Rectangle S2TilesDisplay { get => s2TilesDisplay;}
        public Rectangle S2TilesSource { get => s2TilesSource; }
        public Color S2TilesColor { get => s2TilesColor; }
    }
}
