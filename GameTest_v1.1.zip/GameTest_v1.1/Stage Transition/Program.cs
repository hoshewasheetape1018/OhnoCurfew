﻿using var game = new Stage_Transition.Game1();
game.Run();
